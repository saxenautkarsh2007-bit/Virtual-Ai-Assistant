# ============================================================
# main.py
# Mini Alexa - Virtual AI Assistant (Modular Version)
# ============================================================
#
# This is the main entry point of the project.
# It imports functions from other modules and runs the
# continuous interaction loop.
#
# Architecture (rule-based system):
#   User Input
#        ↓
#   Normalize Input (lowercase + strip)
#        ↓
#   Keyword / Pattern Matching
#        ↓
#   Call the correct function
#        ↓
#   Generate Response
#        ↓
#   Back to Input
# ============================================================

# Import functions from our modules
from greetings import get_user_name
from datetime_utils import get_current_date, get_current_time
from calculator import calculate
from content import get_random_quote, get_random_joke, get_random_fact
from game import play_guessing_game
from ai_concepts import recommend_activity, perceptron_demo
from help_menu import show_help


def main():
    # ---------- Nice heading ----------
    print("=" * 40)
    print("           MINI ALEXA")
    print("      Virtual AI Assistant")
    print("=" * 40)
    print()

    # ---------- 1. Greeting and name capture ----------
    user_name = get_user_name()
    print(f"Assistant: Nice to meet you, {user_name}!")
    print("Assistant: Type 'help' to see what I can do.\n")

    # ---------- 2. Main interaction loop ----------
    while True:
        # Get user input
        user_input = input(f"{user_name}: ").strip()

        # Normalize: convert to lowercase and remove extra spaces
        command = user_input.lower().strip()

        # Empty input
        if command == "":
            print("Assistant: Please type something. Type 'help' for commands.")
            continue

        # ----- Exit commands -----
        if command in ["exit", "quit", "bye"]:
            print(f"Assistant: Goodbye, {user_name}! Have a great day.")
            break

        # ----- Help -----
        elif command == "help":
            show_help()

        # ----- Date -----
        elif command in ["date", "today's date", "what is the date", "tell me the date"]:
            print(f"Assistant: Today's date is {get_current_date()}.")

        # ----- Time -----
        elif command in ["time", "current time", "what time is it", "tell me the time"]:
            print(f"Assistant: The current time is {get_current_time()}.")

        # ----- Calculator (starts with the word "calculate") -----
        elif command.startswith("calculate"):
            result = calculate(command)
            print(f"Assistant: {result}")

        # ----- Motivational quote -----
        elif command in ["quote", "motivational quote", "motivation"]:
            print(f"Assistant: {get_random_quote()}")

        # ----- Joke -----
        elif command in ["joke", "tell me a joke"]:
            print(f"Assistant: {get_random_joke()}")

        # ----- Fact -----
        elif command in ["fact", "tell me a fact", "random fact"]:
            print(f"Assistant: {get_random_fact()}")

        # ----- Number guessing game -----
        elif command in ["game", "guess", "number game", "play game"]:
            play_guessing_game(user_name)

        # ----- Rule-based recommendation -----
        elif command in ["recommend", "recommendation", "suggest"]:
            print(f"Assistant: {recommend_activity()}")

        # ----- Perceptron demonstration -----
        elif command in ["perceptron", "neuron", "demo"]:
            perceptron_demo()

        # ----- Unknown command (fallback) -----
        else:
            print("Assistant: I'm not sure I understood that. Type 'help' to see what I can do.")


# Run the program only when this file is executed directly
if __name__ == "__main__":
    main()

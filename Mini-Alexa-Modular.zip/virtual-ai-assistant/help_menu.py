# ============================================================
# help_menu.py
# Displays all available commands
# ============================================================

def show_help():
    """
    Display the complete list of commands that Mini Alexa understands.
    """
    print("\n========== AVAILABLE COMMANDS ==========")
    print("help          - Show all commands")
    print("date          - Show today's date")
    print("time          - Show current time")
    print("calculate     - Perform a calculation (e.g. calculate 12 + 8)")
    print("quote         - Get a motivational quote")
    print("joke          - Tell a joke")
    print("fact          - Get a random fact")
    print("game          - Play number guessing game")
    print("recommend     - Get an activity recommendation based on time")
    print("perceptron    - Run simple perceptron demonstration")
    print("exit / quit / bye - Exit Mini Alexa")
    print("========================================\n")

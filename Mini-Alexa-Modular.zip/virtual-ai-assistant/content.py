# ============================================================
# content.py
# Stores quotes, jokes and facts
# Uses random.choice() to pick one item
# ============================================================

import random

# ------------------------------------------------------------
# Predefined lists
# ------------------------------------------------------------

MOTIVATIONAL_QUOTES = [
    "Believe you can and you're halfway there.",
    "The only way to do great work is to love what you do.",
    "Don't watch the clock; do what it does. Keep going.",
    "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    "Your limitation—it's only your imagination.",
    "Push yourself, because no one else is going to do it for you.",
    "Great things never come from comfort zones.",
    "Dream it. Wish it. Do it.",
    "The harder you work for something, the greater you'll feel when you achieve it.",
    "Don't stop when you're tired. Stop when you're done."
]

JOKES = [
    "Why did the developer go broke? Because he used up all his cache!",
    "Why do programmers prefer dark mode? Because light attracts bugs!",
    "How many programmers does it take to change a light bulb? None, that's a hardware problem.",
    "Why was the computer cold? It left its Windows open!",
    "What do you call a fake noodle? An impasta!",
    "Why did the student eat his homework? Because the teacher said it was a piece of cake!",
    "What did the ocean say to the beach? Nothing, it just waved!",
    "Why don't scientists trust atoms? Because they make up everything!",
    "What do you call a bear with no teeth? A gummy bear!",
    "Why did the math book look so sad? Because it had too many problems."
]

FACTS = [
    "Honey never spoils. Archaeologists have found pots of honey in ancient Egyptian tombs that are over 3000 years old and still edible.",
    "A group of flamingos is called a 'flamboyance'.",
    "Octopuses have three hearts and blue blood.",
    "Bananas are berries, but strawberries are not.",
    "The shortest war in history lasted only 38 to 45 minutes.",
    "A day on Venus is longer than a year on Venus.",
    "Humans share about 60% of their DNA with bananas.",
    "The Eiffel Tower can be 15 cm taller during the summer due to thermal expansion.",
    "There are more stars in the universe than grains of sand on all the beaches on Earth.",
    "A cloud can weigh more than a million pounds."
]


def get_random_quote():
    """Return a random motivational quote from the list."""
    return random.choice(MOTIVATIONAL_QUOTES)


def get_random_joke():
    """Return a random clean joke from the list."""
    return random.choice(JOKES)


def get_random_fact():
    """Return a random interesting fact from the list."""
    return random.choice(FACTS)

# Mini Alexa - Virtual AI Assistant (Modular Version)

A beginner-friendly, console-based Virtual AI Assistant built with pure Python using a modular structure.

## Description

Mini Alexa is a simple text-based assistant that can:
- Greet the user and remember their name
- Tell the current date and time
- Perform basic calculations
- Share motivational quotes, jokes and facts
- Play a number guessing game
- Recommend an activity based on the time of day
- Demonstrate a simple artificial neuron (perceptron)

It runs completely offline and uses only Python’s standard library.

## Project Structure

```
virtual-ai-assistant/
│
├── main.py              ← Main program (entry point)
├── greetings.py         ← Name capture & greeting
├── datetime_utils.py    ← Date and time functions
├── calculator.py        ← Simple calculator
├── content.py           ← Quotes, jokes and facts
├── game.py              ← Number guessing game
├── ai_concepts.py       ← Recommendation + Perceptron demo
├── help_menu.py         ← Help command
└── README.md            ← This file
```

## Features

- Greeting & name capture
- Date & Time
- Calculator (+, -, *, /) with safe error handling
- Motivational Quotes
- Jokes
- Random Facts
- Number Guessing Game (1-20, 5 attempts)
- Rule-based Activity Recommendation
- Simple Perceptron Demonstration
- Help menu
- Clean exit

## Technologies Used

- Python 3.x
- Standard library only: `random`, `datetime`

## AI Concepts Demonstrated

- Rule-Based System
- Keyword Detection
- Pattern Matching
- Intent Recognition
- Decision Making

## Machine Learning Concept

The recommendation feature shows a **classification analogy**:
- Input → current hour
- Rules → if/elif conditions
- Output → activity category

No real model is trained.

## Deep Learning Concept

The `perceptron` command demonstrates:
- Artificial neuron
- Inputs, weights, bias
- Weighted sum
- Step activation function
- Forward propagation

Weights are fixed (no training).

## Installation

No installation required. Just need Python 3.

## How to Run

1. Open the folder `virtual-ai-assistant` in VS Code.
2. Open the terminal (Ctrl + `).
3. Run the command:

```bash
python main.py
```

## Commands

| Command       | Description                        |
|---------------|------------------------------------|
| help          | Show all commands                  |
| date          | Show today's date                  |
| time          | Show current time                  |
| calculate ... | Perform calculation                |
| quote         | Motivational quote                 |
| joke          | Tell a joke                        |
| fact          | Random fact                        |
| game          | Number guessing game               |
| recommend     | Activity recommendation            |
| perceptron    | Perceptron demo                    |
| exit/quit/bye | Exit the program                   |

## Testing

Test all commands listed above, including invalid inputs, division by zero, non-numeric guesses, and empty input. The program should never crash.

## Limitations

- Text-only (no voice or GUI)
- Rule-based only (no real ML training)
- Calculator supports only two numbers and one operator
- Works for current session only (name is not saved permanently)

## Future Enhancements (ideas)

- Add more commands
- Improve calculator to support more operators
- Add a simple score system for the game
- Save conversation history to a text file

---

Made as a beginner B.Tech CSE / AI-ML project following the modular roadmap.

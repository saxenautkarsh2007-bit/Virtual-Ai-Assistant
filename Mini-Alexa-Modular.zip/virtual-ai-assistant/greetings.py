# ============================================================
# greetings.py
# Handles greeting the user and capturing their name
# ============================================================

def get_user_name():
    """
    Ask for the user's name and return it cleaned.
    If the user presses Enter without typing anything,
    we use "Friend" as a default name.
    """
    print("Assistant: Hi! I'm Mini Alexa. What's your name?")
    name = input("You: ").strip()

    if name == "":
        name = "Friend"

    return name

# ============================================================
# game.py
# Number Guessing Game
# Random number between 1 and 20
# User has 5 attempts
# ============================================================

import random


def play_guessing_game(user_name):
    """
    Number guessing game.
    - Computer chooses a secret number between 1 and 20
    - User has 5 attempts
    - Gives "Higher!" or "Lower!" feedback
    - Handles invalid (non-numeric) input safely
    """
    secret = random.randint(1, 20)
    attempts_left = 5

    print(f"\nAssistant: I'm thinking of a number between 1 and 20.")
    print(f"Assistant: You have {attempts_left} tries. Good luck, {user_name}!")

    while attempts_left > 0:
        guess_str = input(f"{user_name}: ").strip()

        # Handle empty input
        if guess_str == "":
            print("Assistant: Please enter a number.")
            continue

        # Handle non-numeric input
        try:
            guess = int(guess_str)
        except ValueError:
            print("Assistant: That's not a valid number. Try again.")
            continue

        # Handle number outside range
        if guess < 1 or guess > 20:
            print("Assistant: Please guess a number between 1 and 20.")
            continue

        # Check the guess
        if guess == secret:
            print(f"Assistant: Correct! Well done, {user_name}! The number was {secret}.")
            return
        elif guess < secret:
            print("Assistant: Higher!")
        else:
            print("Assistant: Lower!")

        attempts_left -= 1
        if attempts_left > 0:
            print(f"Assistant: You have {attempts_left} tries left.")

    # If all attempts are used
    print(f"Assistant: Out of tries! The number was {secret}. Better luck next time!")

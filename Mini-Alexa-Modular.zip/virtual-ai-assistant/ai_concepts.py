# ============================================================
# ai_concepts.py
# Demonstrates AI / ML / DL concepts using simple Python logic
# NO real model training, NO TensorFlow / PyTorch / NumPy
# ============================================================

from datetime import datetime


def recommend_activity():
    """
    Rule-based recommendation system.

    This demonstrates a simple RULE-BASED AI decision system.
    It is NOT a trained machine learning model.

    How it works (beginner explanation):
    - Input feature  → current hour of the day
    - Decision rules → if / elif / else conditions
    - Output category → activity recommendation

    This is similar to a very simple classifier.
    """
    # Get current hour (0 to 23)
    hour = datetime.now().hour

    # Rule-based decision making
    if 5 <= hour < 12:
        return "Good morning! It's a good time for breakfast or a short walk."
    elif 12 <= hour < 17:
        return "It's afternoon. You could focus on study or have lunch."
    elif 17 <= hour < 21:
        return "It's evening. You could relax, go for a walk, or finish pending work."
    else:
        return "It's late. Consider getting some rest or preparing for tomorrow."


def perceptron_demo():
    """
    Simple educational demonstration of an artificial neuron (perceptron).

    Concepts shown:
    - Inputs
    - Weights
    - Bias
    - Weighted sum
    - Step activation function
    - Output (0 or 1)
    - Forward propagation

    IMPORTANT:
    - This is NOT training.
    - Weights and bias are fixed (hard-coded).
    - No NumPy, TensorFlow or PyTorch is used.
    """
    print("\n========== PERCEPTRON DEMONSTRATION ==========")
    print("This is a simplified educational demo of an artificial neuron.")
    print("You will give 2 numeric inputs.")
    print("I will use fixed weights and bias, then apply a step activation.\n")

    # Fixed weights and bias (not learned / not trained)
    weight1 = 0.5
    weight2 = -0.6
    bias = 0.1

    # Get two inputs from the user
    try:
        input1 = float(input("Enter first input number: ").strip())
        input2 = float(input("Enter second input number: ").strip())
    except ValueError:
        print("Assistant: Please enter valid numbers only.")
        return

    # ---------- Forward Propagation ----------
    # 1. Calculate weighted sum
    weighted_sum = (input1 * weight1) + (input2 * weight2) + bias

    # 2. Apply step activation function
    if weighted_sum > 0:
        output = 1
    else:
        output = 0

    # ---------- Display Results ----------
    print("\n----- Results -----")
    print(f"Input 1        : {input1}")
    print(f"Input 2        : {input2}")
    print(f"Weight 1       : {weight1}")
    print(f"Weight 2       : {weight2}")
    print(f"Bias           : {bias}")
    print(f"Weighted sum   : {weighted_sum:.4f}")
    print(f"Activation     : Step function (output = 1 if sum > 0 else 0)")
    print(f"Output         : {output}")
    print("==============================================\n")

    print("Explanation (for your understanding):")
    print("- Inputs are the numbers you provided.")
    print("- Weights decide how important each input is.")
    print("- Bias shifts the decision boundary.")
    print("- Weighted sum is the combined signal.")
    print("- Activation function decides the final output (0 or 1).")
    print("- This whole process is called forward propagation.")

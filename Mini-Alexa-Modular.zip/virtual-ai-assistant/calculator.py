# ============================================================
# calculator.py
# Simple two-number calculator
# Supports +, -, *, /
# Does NOT use eval() for safety
# ============================================================

def calculate(command):
    """
    Simple two-number calculator.
    Expected format: calculate 12 + 8

    Supports: +  -  *  /
    Handles division by zero safely.
    Handles invalid input without crashing.
    """
    # Remove the word "calculate" and extra spaces
    expression = command.replace("calculate", "").strip()

    if expression == "":
        return "Please give me a calculation. Example: calculate 12 + 8"

    # Split into parts → number operator number
    parts = expression.split()

    if len(parts) != 3:
        return "I can only do simple calculations like: calculate 12 + 8"

    num1_str, operator, num2_str = parts

    # Try to convert the two parts to numbers
    try:
        num1 = float(num1_str)
        num2 = float(num2_str)
    except ValueError:
        return "Please enter valid numbers. Example: calculate 10 * 5"

    # Perform the operation based on the operator
    if operator == "+":
        result = num1 + num2
    elif operator == "-":
        result = num1 - num2
    elif operator == "*":
        result = num1 * num2
    elif operator == "/":
        if num2 == 0:
            return "I can't divide by zero — try a different number."
        result = num1 / num2
    else:
        return "I only support +, -, * and /. Example: calculate 20 / 4"

    # Show nicer output for whole numbers (e.g. 20 instead of 20.0)
    if result == int(result):
        result = int(result)

    return f"The result is {result}"

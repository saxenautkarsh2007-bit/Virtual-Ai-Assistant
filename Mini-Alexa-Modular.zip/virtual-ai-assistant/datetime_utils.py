# ============================================================
# datetime_utils.py
# Handles date and time using Python's built-in datetime module
# ============================================================

from datetime import datetime


def get_current_date():
    """
    Return the current system date in a readable format.
    Example: Wednesday, 10 September 2026
    """
    now = datetime.now()
    return now.strftime("%A, %d %B %Y")


def get_current_time():
    """
    Return the current system time in 12-hour format.
    Example: 02:45 PM
    """
    now = datetime.now()
    return now.strftime("%I:%M %p")
